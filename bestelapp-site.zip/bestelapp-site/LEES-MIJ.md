# Bestelapp online zetten (gratis)

## 1. Database — Supabase
1. Ga naar supabase.com, maak gratis account, "New project".
2. Ga naar **SQL Editor** > New query, plak de inhoud van `schema.sql`, klik Run.
3. Ga naar **Project Settings > API**. Kopieer de "Project URL" en de "anon public" key.
4. Open `config.js` en vul beide in bij `SUPABASE_URL` en `SUPABASE_ANON_KEY`.
5. Verander ook `ADMIN_PASSWORD` naar iets van jezelf.

## 2. Code op GitHub
1. Maak gratis account op github.com.
2. Maak een nieuwe (private of public) repository, bv. "bestelapp".
3. Upload alle bestanden uit deze map (index.html, admin.html, style.css, config.js, schema.sql) via "Add file > Upload files".

## 3. Live zetten — Vercel
1. Ga naar vercel.com, log in met je GitHub-account (gratis).
2. "Add New... > Project", kies je "bestelapp" repository.
3. Laat de instellingen op standaard staan, klik Deploy.
4. Na een halve minuut krijg je een link zoals `bestelapp.vercel.app` — dat is je website.

Klaar. Iedereen met de link kan bestellen op `/index.html`, en jullie beheren
producten/bestellingen op `/admin.html` (achter je wachtwoord).

## Let op
- Het wachtwoordschermpje houdt gewone bezoekers tegen, maar is geen
  bankkluis-beveiliging — voldoende voor een interne teamapp, niet voor
  gevoelige gegevens.
- Wijzig je `SUPABASE_ANON_KEY` gerust niet als "geheim": die key is
  bedoeld om zichtbaar te zijn in de website-code.
